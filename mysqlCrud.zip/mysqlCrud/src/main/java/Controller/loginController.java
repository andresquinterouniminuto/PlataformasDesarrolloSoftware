/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.LoginQuerys;
import Model.LoginUser;
import Model.UserQuerys;
import Model.Users;
import View.FrmLogin;
import View.FrmUsers;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class loginController implements ActionListener{
    private LoginUser us;
    private LoginQuerys querys;
    private FrmLogin frmLogin;
    
    
    public loginController (LoginUser us,LoginQuerys querys,FrmLogin frmLogin){
        this.us = us;
        this.querys = querys;
        this.frmLogin = frmLogin;
        this.frmLogin.btnVisualizar.addActionListener(this);
        this.frmLogin.btnEntrar.addActionListener(this);
    }
    
    
    public void init(){
        frmLogin.setTitle("Login");
        frmLogin.setLocationRelativeTo(null); 
        frmLogin.btnVisualizar.setSelected(false);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == frmLogin.btnEntrar)
        {
            boolean isUser = false;
            us.setEmail(frmLogin.txtEmail.getText());
            us.setPassword(frmLogin.txtPassword.getText());
            isUser = querys.validateUserAndPassword(us);
            if(isUser){
                Users us = new Users();
                UserQuerys querys = new UserQuerys();
                FrmUsers frm = new FrmUsers();
        
                userController usController = new userController(us,querys,frm);
                usController.init();
                frmLogin.setVisible(false);
                frm.setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(frmLogin,"El usuario o la contraseña no coinciden", "Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        else if(e.getSource() == frmLogin.btnVisualizar) 
        {
            if(frmLogin.btnVisualizar.getText().equals("Ocultar")){
                frmLogin.btnVisualizar.setText("Ver");
                frmLogin.txtPassword.setEchoChar('•'); 
            }
            else{
                frmLogin.txtPassword.setEchoChar((char)0); 
                frmLogin.btnVisualizar.setText("Ocultar");
            }
            
            
        }
    }
    
    
    
}
