/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.UserQuerys;
import Model.Users;
import View.FrmUsers;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Dell
 */
public class userController implements ActionListener,MouseListener{
    
    private Users us;
    private UserQuerys querys;
    private FrmUsers frmUsers;
    
    
    public userController(Users us, UserQuerys querys,FrmUsers frmUsers){
        this.us = us;
        this.querys = querys;
        this.frmUsers = frmUsers;
        this.frmUsers.btnCreate.addActionListener(this);
        this.frmUsers.btnDelete.addActionListener(this);
        this.frmUsers.btnRead.addActionListener(this);
        this.frmUsers.btnUpdate.addActionListener(this);
        this.frmUsers.tablaUsuarios.addMouseListener(this);
        
        
        
        
    }
    
    public void init(){
        frmUsers.setTitle("Usuarios");
        frmUsers.setLocationRelativeTo(null);
        frmUsers.txtIdUser.setVisible(false);
        llenarTablaUsuarios();
        
    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(e.getSource());
        if(e.getSource() == frmUsers.btnCreate)
        {
            us.setFisrtName(frmUsers.txtFirstName.getText());
            us.setLastName(frmUsers.txtLastName.getText());
            us.setId(frmUsers.txtId.getText());
            us.setPhone(frmUsers.txtPhone.getText());
            us.setEmail(frmUsers.txtEmail.getText());
            us.setPass(frmUsers.txtPass.getText());
            //JOptionPane.showMessageDialog(null,us);
            if(querys.create(us)){
                JOptionPane.showMessageDialog(null,"Usuario Guardado");
                clean();
                llenarTablaUsuarios();
            }
            else{
                JOptionPane.showMessageDialog(null,"Error al Guardar Usuario");
            }
        }
        else if(e.getSource() == frmUsers.btnUpdate){
            us.setFisrtName(frmUsers.txtFirstName.getText());
            us.setLastName(frmUsers.txtLastName.getText());
            us.setId(frmUsers.txtId.getText());
            us.setPhone(frmUsers.txtPhone.getText());
            us.setEmail(frmUsers.txtEmail.getText());
            us.setPass(frmUsers.txtPass.getText());
            us.setIdUser(frmUsers.txtIdUser.getText());
            if(querys.update(us)){
                JOptionPane.showMessageDialog(null,"Usuario Actualizado");
                clean();
                llenarTablaUsuarios();
            }
            else{
                JOptionPane.showMessageDialog(null,"Error al Actualizar Usuario");
            }
        }
        else if(e.getSource() == frmUsers.btnDelete){
            if(querys.delete(us)){
                JOptionPane.showMessageDialog(null,"Usuario Borrado");
                clean();
                llenarTablaUsuarios();
            }
            else{
                JOptionPane.showMessageDialog(null,"Error al Borrar Usuario");
            }
        }
        else if (e.getSource() == frmUsers.btnRead){
            us = querys.getUser(frmUsers.txtId.getText());
            frmUsers.txtFirstName.setText(us.getFisrtName());
            frmUsers.txtLastName.setText(us.getLastName());
            frmUsers.txtId.setText(us.getId());
            frmUsers.txtPhone.setText(us.getPhone());
            frmUsers.txtEmail.setText(us.getEmail());
            frmUsers.txtPass.setText(us.getPass());
            frmUsers.txtIdUser.setText(us.getIdUser());
            
        }
    }
    
    public void clean(){
        frmUsers.txtFirstName.setText(null);
        frmUsers.txtLastName.setText(null);
        frmUsers.txtId.setText(null);
        frmUsers.txtPhone.setText(null);
        frmUsers.txtEmail.setText(null);
        frmUsers.txtPass.setText(null);
    }
    
    private void llenarTablaUsuarios(){
        DefaultTableModel tabla = new DefaultTableModel();
        ArrayList<Users> datos;
        String[] row = new String[7];
        tabla.addColumn("IdUser");
        tabla.addColumn("FirstName");
        tabla.addColumn("LastName");
        tabla.addColumn("Identification");
        tabla.addColumn("Phone");
        tabla.addColumn("Email");
        tabla.addColumn("Pass");
        datos = querys.llenarDatosUsuarios();
        for(int i = 0; i< datos.size();i++){
            row[0] = datos.get(i).getIdUser();
            row[1] = datos.get(i).getFisrtName();
            row[2] = datos.get(i).getLastName();
            row[3] = datos.get(i).getId();
            row[4] = datos.get(i).getPhone();
            row[5] = datos.get(i).getEmail();
            row[6] = datos.get(i).getPass();
            tabla.addRow(row);
        }
        frmUsers.tablaUsuarios.setModel(tabla);
        
        
        
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int row = frmUsers.tablaUsuarios.getSelectedRow();
        us.setIdUser((String)frmUsers.tablaUsuarios.getValueAt(row, 0));
        us.setId((String)frmUsers.tablaUsuarios.getValueAt(row, 3));
        us.setFisrtName((String)frmUsers.tablaUsuarios.getValueAt(row, 1));
        us.setLastName((String)frmUsers.tablaUsuarios.getValueAt(row, 2));
        us.setEmail((String)frmUsers.tablaUsuarios.getValueAt(row, 5));
        us.setPhone((String)frmUsers.tablaUsuarios.getValueAt(row, 4));
        us.setPass((String)frmUsers.tablaUsuarios.getValueAt(row, 6));
        frmUsers.txtFirstName.setText(us.getFisrtName());
        frmUsers.txtLastName.setText(us.getLastName());
        frmUsers.txtId.setText(us.getId());
        frmUsers.txtPhone.setText(us.getPhone());
        frmUsers.txtEmail.setText(us.getEmail());
        frmUsers.txtPass.setText(us.getPass());
        frmUsers.txtIdUser.setText(us.getIdUser());
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
