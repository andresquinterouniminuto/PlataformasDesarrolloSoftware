/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.semana2.mysqlcrud;

import Controller.loginController;
import Controller.userController;
import Model.LoginQuerys;
import Model.LoginUser;
import Model.UserQuerys;
import Model.Users;
import View.FrmLogin;
import View.FrmUsers;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Dell
 */
public class MysqlCrud {

    public static void main(String[] args) {
        
        LoginUser lus = new LoginUser();
        LoginQuerys lquerys = new LoginQuerys();
        FrmLogin frmLogin = new FrmLogin();
        
        loginController lcontroller = new loginController(lus,lquerys,frmLogin);
        lcontroller.init();
        frmLogin.setVisible(true);
        
        /*Users us = new Users();
        UserQuerys querys = new UserQuerys();
        FrmUsers frm = new FrmUsers();
        
        userController usController = new userController(us,querys,frm);
        usController.init();
        frm.setVisible(true);
        */
    }
}
