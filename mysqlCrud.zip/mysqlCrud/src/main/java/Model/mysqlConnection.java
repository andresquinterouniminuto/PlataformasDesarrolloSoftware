/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Dell
 */
public class mysqlConnection {
    
    private final String db_name = "db_users";
    private final String user = "admin";
    private final String password = "Uniminuto12345*";
    private final String url = "jdbc:mysql://localhost:3306/"+db_name;
    
    private Connection con = null;
    
    public Connection getConnection(){
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(this.url,this.user,this.password);
        }
        catch(SQLException e){
            System.err.println(e);
        }
        return con;
    }
}
