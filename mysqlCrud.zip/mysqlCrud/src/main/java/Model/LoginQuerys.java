/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Dell
 */
public class LoginQuerys extends mysqlConnection{
    
    public boolean validateUserAndPassword(LoginUser Luser){
        PreparedStatement ps = null;
        boolean respuesta = false;
        ResultSet rs;
        Connection con = getConnection();
        String query = "CALL p_validateUserAndPassword(?,?)";
        try{
            ps = con.prepareStatement(query);
            ps.setString(1, Luser.getEmail());
            ps.setString(2, Luser.getPassword());
            rs = ps.executeQuery();
            while(rs.next()){
                
                if(rs.getString("respuesta").equals("1")){
                    respuesta = true;
                }
                System.out.println(rs.getString("respuesta"));
            }
            
            return respuesta;
        }
        catch(SQLException e){
            System.err.println(e);
            return false; 
        }
        finally{
            try{
                con.close();
            }
            catch(SQLException e){
                System.err.println(e);
            }
        }
    }
    
}
