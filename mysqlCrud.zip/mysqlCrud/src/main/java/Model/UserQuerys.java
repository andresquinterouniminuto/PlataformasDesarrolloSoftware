/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author Dell
 */
public class UserQuerys extends mysqlConnection{
    
    public ArrayList<Users> llenarDatosUsuarios(){
        Users usuario;
        ResultSet rs;
        PreparedStatement ps = null;
        Connection con = getConnection();
        ArrayList<Users> lista = new ArrayList<>();
        String query = "CALL p_getAllUsers";
        try{
            ps = con.prepareStatement(query);	
            rs = ps.executeQuery();
            while(rs.next()){
                usuario = new Users();
                usuario.setIdUser(rs.getString("IdUsers"));
                usuario.setFisrtName(rs.getString("Firstname"));
                usuario.setLastName(rs.getString("LastName"));
                usuario.setId(rs.getString("Id"));
                usuario.setEmail(rs.getString("Email"));
                usuario.setPhone(rs.getString("Phone"));
                usuario.setPass(rs.getString("Pass"));
                lista.add(usuario);
            }   
            rs.close();
            ps.close();
            con.close();
        }
        catch(SQLException e){
           System.err.println(e); 
        }
    return lista;
    }
    
    public boolean create(Users us){
        PreparedStatement ps = null;
        Connection con = getConnection();
        
        String query = "CALL p_InsertNewUser(?,?,?,?,?,?)";
        try{
            ps = con.prepareStatement(query);
            ps.setString(1, us.getFisrtName());
            ps.setString(2, us.getLastName());
            ps.setString(3, us.getEmail());
            ps.setString(4, us.getPhone());
            ps.setString(5, us.getId());
            ps.setString(6, us.getPass());
            ps.execute();
            return true;
        }
        catch(SQLException e){
            System.err.println(e);
            return false; 
        }
        finally{
            try{
                con.close();
            }
            catch(SQLException e){
                System.err.println(e);
            }
        }
    }
    
    public boolean delete(Users us){
        PreparedStatement ps = null;
        Connection con = getConnection();
        String query = "CALL p_DeleteByIdUser(?)";
        try{
            ps = con.prepareStatement(query);
            ps.setString(1, us.getIdUser());
            ps.execute();
            return true;
        }
        catch(SQLException e){
            System.err.println(e);
            return false; 
        }
        finally{
            try{
                con.close();
            }
            catch(SQLException e){
                System.err.println(e);
            }
        }
    }
    
    
    public boolean update(Users us){
        PreparedStatement ps = null;
        Connection con = getConnection();
        
        String query = "CALL p_UpdateUserXIdUser(?,?,?,?,?,?,?)";
        try{
            ps = con.prepareStatement(query);
            ps.setString(1, us.getIdUser());
            ps.setString(2, us.getFisrtName());
            ps.setString(3, us.getLastName());
            ps.setString(4, us.getEmail());
            ps.setString(5, us.getPhone());
            ps.setString(6, us.getId());
            ps.setString(7, us.getPass());
            ps.execute();
            return true;
        }
        catch(SQLException e){
            System.err.println(e);
            return false; 
        }
        finally{
            try{
                con.close();
            }
            catch(SQLException e){
                System.err.println(e);
            }
        }
    }
    
    public Users getUser(String Id){
        Users user = new Users();
        PreparedStatement ps = null;
        Connection con = getConnection();
        
        String query = "CALL p_ReadUserById(?)";
        try{
            ResultSet rs;
            ps = con.prepareStatement(query);
            ps.setString(1, Id);
            rs = ps.executeQuery();
            while(rs.next()){
                user.setFisrtName(rs.getString("FirstName"));
                user.setLastName(rs.getString("LastName"));
                user.setEmail(rs.getString("Email"));
                user.setPass(rs.getString("Pass"));
                user.setId(rs.getString("Id"));
                user.setIdUser(rs.getString("IdUsers"));
                user.setPhone(rs.getString("Phone"));
            }
            rs.close();
            ps.close();
            
            
           
        }
        catch(SQLException e){
            System.err.println(e);
        }
        finally{
            try{
                con.close();
            }
            catch(SQLException e){
                System.err.println(e);
            }
        }
        return user;
    }

    
}
